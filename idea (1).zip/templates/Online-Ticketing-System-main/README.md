# Documantion 

### Online-Ticketing-System

This is a simple online ticket booking system designed in HTML and CSS. Moreover, this simple looking ticket booking system is designed for the students to help them to give a concept on how to design this sort of pages in responsive mode.
